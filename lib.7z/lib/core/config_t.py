# ------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
# ------------------------------------------------------------------------------

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import yaml

import numpy as np
from easydict import EasyDict as edict

config_t = edict()

config_t.OUTPUT_DIR = 'output'
config_t.LOG_DIR = 'log'
config_t.DATA_DIR = ''
config_t.BACKBONE_MODEL = 'pose_resnet'
config_t.MODEL = 'multi_person_posenet'
config_t.GPUS = '0,1'
config_t.WORKERS = 8
config_t.PRINT_FREQ = 100

# higherhrnet definition
config_t.MODEL_EXTRA = edict()
config_t.MODEL_EXTRA.PRETRAINED_LAYERS = ['*']
config_t.MODEL_EXTRA.FINAL_CONV_KERNEL = 1
config_t.MODEL_EXTRA.STEM_INPLANES = 64

config_t.MODEL_EXTRA.STAGE2 = edict()
config_t.MODEL_EXTRA.STAGE2.NUM_MODULES = 1
config_t.MODEL_EXTRA.STAGE2.NUM_BRANCHES= 2
config_t.MODEL_EXTRA.STAGE2.BLOCK = 'BASIC'
config_t.MODEL_EXTRA.STAGE2.NUM_BLOCKS = [4, 4]
config_t.MODEL_EXTRA.STAGE2.NUM_CHANNELS = [48, 96]
config_t.MODEL_EXTRA.STAGE2.FUSE_METHOD = 'SUM'

config_t.MODEL_EXTRA.STAGE3 = edict()
config_t.MODEL_EXTRA.STAGE3.NUM_MODULES = 4
config_t.MODEL_EXTRA.STAGE3.NUM_BRANCHES = 3
config_t.MODEL_EXTRA.STAGE3.BLOCK = 'BASIC'
config_t.MODEL_EXTRA.STAGE3.NUM_BLOCKS = [4, 4, 4]
config_t.MODEL_EXTRA.STAGE3.NUM_CHANNELS = [48, 96, 192]
config_t.MODEL_EXTRA.STAGE3.FUSE_METHOD = 'SUM'

config_t.MODEL_EXTRA.STAGE4 = edict()
config_t.MODEL_EXTRA.STAGE4.NUM_MODULES = 3
config_t.MODEL_EXTRA.STAGE4.NUM_BRANCHES = 4
config_t.MODEL_EXTRA.STAGE4.BLOCK = 'BASIC'
config_t.MODEL_EXTRA.STAGE4.NUM_BLOCKS = [4, 4, 4, 4]
config_t.MODEL_EXTRA.STAGE4.NUM_CHANNELS = [48, 96, 192, 384]
config_t.MODEL_EXTRA.STAGE4.FUSE_METHOD = 'SUM'

config_t.MODEL_EXTRA.DECONV = edict()
config_t.MODEL_EXTRA.DECONV.NUM_DECONVS = 1
config_t.MODEL_EXTRA.DECONV.NUM_CHANNELS = 32
config_t.MODEL_EXTRA.DECONV.KERNEL_SIZE = 4
config_t.MODEL_EXTRA.DECONV.NUM_BASIC_BLOCKS = 4
config_t.MODEL_EXTRA.DECONV.CAT_OUTPUT = True

# Cudnn related params
config_t.CUDNN = edict()
config_t.CUDNN.BENCHMARK = True
config_t.CUDNN.DETERMINISTIC = False
config_t.CUDNN.ENABLED = True

# common params for NETWORK
config_t.NETWORK = edict()
config_t.NETWORK.PRETRAINED = 'models/pytorch/imagenet/resnet50-19c8e357.pth'
config_t.NETWORK.PRETRAINED_BACKBONE = ''
config_t.NETWORK.NUM_JOINTS = 20
config_t.NETWORK.INPUT_SIZE = 512
config_t.NETWORK.HEATMAP_SIZE = np.array([80, 80])
config_t.NETWORK.IMAGE_SIZE = np.array([320, 320])
config_t.NETWORK.SIGMA = 2
config_t.NETWORK.TARGET_TYPE = 'gaussian'
config_t.NETWORK.AGGRE = True
config_t.NETWORK.USE_GT = False
config_t.NETWORK.BETA = 100.0

# pose_resnet related params
config_t.POSE_RESNET = edict()
config_t.POSE_RESNET.NUM_LAYERS = 50
config_t.POSE_RESNET.DECONV_WITH_BIAS = False
config_t.POSE_RESNET.NUM_DECONV_LAYERS = 3
config_t.POSE_RESNET.NUM_DECONV_FILTERS = [256, 256, 256]
config_t.POSE_RESNET.NUM_DECONV_KERNELS = [4, 4, 4]
config_t.POSE_RESNET.FINAL_CONV_KERNEL = 1

config_t.LOSS = edict()
config_t.LOSS.USE_TARGET_WEIGHT = True
config_t.LOSS.USE_DIFFERENT_JOINTS_WEIGHT = False

# DATASET related params
config_t.DATASET = edict()
config_t.DATASET.ROOT = '../data/h36m/'
config_t.DATASET.TRAIN_DATASET = 'mixed_dataset'
config_t.DATASET.TEST_DATASET = 'multi_view_h36m'
config_t.DATASET.TRAIN_SUBSET = 'train'
config_t.DATASET.TEST_SUBSET = 'validation'
config_t.DATASET.ROOTIDX = 2
config_t.DATASET.DATA_FORMAT = 'jpg'
config_t.DATASET.BBOX = 2000
config_t.DATASET.CROP = True
config_t.DATASET.COLOR_RGB = False
config_t.DATASET.FLIP = True
config_t.DATASET.DATA_AUGMENTATION = True
config_t.DATASET.CAMERA_NUM = 5

# training data augmentation
config_t.DATASET.SCALE_FACTOR = 0
config_t.DATASET.ROT_FACTOR = 0

# train
config_t.TRAIN = edict()
config_t.TRAIN.LR_FACTOR = 0.1
config_t.TRAIN.LR_STEP = [90, 110]
config_t.TRAIN.LR = 0.001

config_t.TRAIN.OPTIMIZER = 'adam'
config_t.TRAIN.MOMENTUM = 0.9
config_t.TRAIN.WD = 0.0001
config_t.TRAIN.NESTEROV = False
config_t.TRAIN.GAMMA1 = 0.99
config_t.TRAIN.GAMMA2 = 0.0

config_t.TRAIN.BEGIN_EPOCH = 0
config_t.TRAIN.END_EPOCH = 140

config_t.TRAIN.RESUME = False

config_t.TRAIN.BATCH_SIZE = 8
config_t.TRAIN.SHUFFLE = True

# testing
config_t.TEST = edict()
config_t.TEST.BATCH_SIZE = 8
config_t.TEST.STATE = 'best'
config_t.TEST.FLIP_TEST = False
config_t.TEST.POST_PROCESS = False
config_t.TEST.SHIFT_HEATMAP = False
config_t.TEST.USE_GT_BBOX = False
config_t.TEST.IMAGE_THRE = 0.1
config_t.TEST.NMS_THRE = 0.6
config_t.TEST.OKS_THRE = 0.5
config_t.TEST.IN_VIS_THRE = 0.0
config_t.TEST.BBOX_FILE = ''
config_t.TEST.BBOX_THRE = 1.0
config_t.TEST.MATCH_IOU_THRE = 0.3
config_t.TEST.DETECTOR = 'fpn_dcn'
config_t.TEST.DETECTOR_DIR = ''
config_t.TEST.MODEL_FILE = ''
config_t.TEST.HEATMAP_LOCATION_FILE = 'predicted_heatmaps.h5'

# debug
config_t.DEBUG = edict()
config_t.DEBUG.DEBUG = True
config_t.DEBUG.SAVE_BATCH_IMAGES_GT = True
config_t.DEBUG.SAVE_BATCH_IMAGES_PRED = True
config_t.DEBUG.SAVE_HEATMAPS_GT = True
config_t.DEBUG.SAVE_HEATMAPS_PRED = True

# pictorial structure
config_t.PICT_STRUCT = edict()
config_t.PICT_STRUCT.FIRST_NBINS = 16
config_t.PICT_STRUCT.PAIRWISE_FILE = ''
config_t.PICT_STRUCT.RECUR_NBINS = 2
config_t.PICT_STRUCT.RECUR_DEPTH = 10
config_t.PICT_STRUCT.LIMB_LENGTH_TOLERANCE = 150
config_t.PICT_STRUCT.GRID_SIZE = np.array([2000.0, 2000.0, 2000.0])
config_t.PICT_STRUCT.CUBE_SIZE = np.array([64, 64, 64])
config_t.PICT_STRUCT.DEBUG = False
config_t.PICT_STRUCT.TEST_PAIRWISE = False
config_t.PICT_STRUCT.SHOW_ORIIMG = False
config_t.PICT_STRUCT.SHOW_CROPIMG = False
config_t.PICT_STRUCT.SHOW_HEATIMG = False

config_t.MULTI_PERSON = edict()
config_t.MULTI_PERSON.SPACE_SIZE = np.array([4000.0, 5200.0, 2400.0])
config_t.MULTI_PERSON.SPACE_CENTER = np.array([300.0, 300.0, 300.0])
config_t.MULTI_PERSON.INITIAL_CUBE_SIZE = np.array([24, 32, 16])
config_t.MULTI_PERSON.MAX_PEOPLE_NUM = 10
config_t.MULTI_PERSON.THRESHOLD = 0.1


def _update_dict_t(k, v):
    if k == 'DATASET':
        if 'MEAN' in v and v['MEAN']:
            v['MEAN'] = np.array(
                [eval(x) if isinstance(x, str) else x for x in v['MEAN']])
        if 'STD' in v and v['STD']:
            v['STD'] = np.array(
                [eval(x) if isinstance(x, str) else x for x in v['STD']])
    if k == 'NETWORK':
        if 'HEATMAP_SIZE' in v:
            if isinstance(v['HEATMAP_SIZE'], int):
                v['HEATMAP_SIZE'] = np.array(
                    [v['HEATMAP_SIZE'], v['HEATMAP_SIZE']])
            else:
                v['HEATMAP_SIZE'] = np.array(v['HEATMAP_SIZE'])
        if 'IMAGE_SIZE' in v:
            if isinstance(v['IMAGE_SIZE'], int):
                v['IMAGE_SIZE'] = np.array([v['IMAGE_SIZE'], v['IMAGE_SIZE']])
            else:
                v['IMAGE_SIZE'] = np.array(v['IMAGE_SIZE'])
    for vk, vv in v.items():
        if vk in config_t[k]:
            config_t[k][vk] = vv
        else:
            raise ValueError("{}.{} not exist in config.py".format(k, vk))


def update_config_t(config_file):
    exp_config = None
    with open(config_file) as f:
        exp_config = edict(yaml.load(f, Loader=yaml.FullLoader))
        for k, v in exp_config.items():
            if k in config_t:
                if isinstance(v, dict):
                    _update_dict_t(k, v)
                else:
                    if k == 'SCALES':
                        config_t[k][0] = (tuple(v))
                    else:
                        config_t[k] = v
            else:
                raise ValueError("{} not exist in config.py".format(k))


def gen_config_t(config_file):
    cfg = dict(config_t)
    for k, v in cfg.items():
        if isinstance(v, edict):
            cfg[k] = dict(v)

    with open(config_file, 'w') as f:
        yaml.dump(dict(cfg), f, default_flow_style=False)


def update_dir_t(model_dir, log_dir, data_dir):
    if model_dir:
        config_t.OUTPUT_DIR = model_dir

    if log_dir:
        config_t.LOG_DIR = log_dir

    if data_dir:
        config_t.DATA_DIR = data_dir

    config_t.DATASET.ROOT = os.path.join(config_t.DATA_DIR, config_t.DATASET.ROOT)

    config_t.TEST.BBOX_FILE = os.path.join(config_t.DATA_DIR, config_t.TEST.BBOX_FILE)

    config_t.NETWORK.PRETRAINED = os.path.join(config_t.DATA_DIR,
                                             config_t.NETWORK.PRETRAINED)


def get_model_name(cfg):
    name = '{model}_{num_layers}'.format(
        model=cfg.MODEL, num_layers=cfg.POSE_RESNET.NUM_LAYERS)
    deconv_suffix = ''.join(
        'd{}'.format(num_filters)
        for num_filters in cfg.POSE_RESNET.NUM_DECONV_FILTERS)
    full_name = '{height}x{width}_{name}_{deconv_suffix}'.format(
        height=cfg.NETWORK.IMAGE_SIZE[1],
        width=cfg.NETWORK.IMAGE_SIZE[0],
        name=name,
        deconv_suffix=deconv_suffix)

    return name, full_name


if __name__ == '__main__':
    import sys
    gen_config_t(sys.argv[1])
