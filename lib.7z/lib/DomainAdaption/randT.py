import torch

def randomT():
    return torch.rand(1)