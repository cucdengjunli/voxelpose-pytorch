from typing import Any, Optional, Tuple
from torch.autograd import Function
import torch.nn as nn
import torch
import torch.optim as optim
import torch.nn.functional as F
import random
import numpy


# Autograd Function objects are what record operation history on tensors,
# and define formulas for the forward and backprop.
class GradientReversalFn(Function):
    @staticmethod
    def forward(ctx, x, alpha):
        # Store context for backprop
        ctx.alpha = alpha
        
        # Forward pass is a no-op
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        # Backward pass is just to -alpha the gradient
        output = grad_output.neg() * ctx.alpha

        # Must return same number as inputs to forward()
        return output, None


class DACNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.domain_classifier = nn.Sequential(
            nn.Linear(3 * 256 * 32 * 60, 30),
            # nn.BatchNorm1d(100),
            nn.ReLU(True),
            nn.Linear(30, 2),
            nn.LogSoftmax(dim=1),
        )

    def forward(self, features, grl_lambda=1.0):
        # Handle single-channel input by expanding (repeating) the singleton dimention
        features = F.max_pool2d(features, 4, stride=4)
        # print('平均池化features.shape:', features.shape)
        features = features.view(-1, 3 * 256 * 32 * 60)
        # print('features.shape:', features.shape)
        reverse_features = GradientReversalFn.apply(features, grl_lambda)
        # print('reverse_features.shape:', reverse_features.shape)
        domain_pred = self.domain_classifier(reverse_features)
        return domain_pred



#######################################################################
#
# model = DACNN().to(device)
#
# # 训练
#
# # Setup optimizer as usual
# optimizer = optim.Adam(model.parameters(), lr)
#
# # Two losses functions this time
# loss_fn_class = torch.nn.NLLLoss()
# loss_fn_domain = torch.nn.NLLLoss()
#
# dl_source = torch.utils.data.DataLoader(ds_source, batch_size)
# dl_target = torch.utils.data.DataLoader(ds_target, batch_size)
#
# # We'll train the same number of batches from both datasets
# # max_batches = min(len(dl_source), len(dl_target))
# max_batches = 5000
#
# for epoch_idx in range(n_epochs):
#     print(f'Epoch {epoch_idx + 1:04d} / {n_epochs:04d}', end='\n=================\n')
#     dl_source_iter = iter(dl_source)
#     dl_target_iter = iter(dl_target)
#
#     for batch_idx in range(max_batches):
#         optimizer.zero_grad()
#         # Training progress and GRL lambda
#         p = float(batch_idx + epoch_idx * max_batches) / (n_epochs * max_batches)
#         grl_lambda = 2. / (1. + np.exp(-10 * p)) - 1
#
#         # Train on source domain
#         X_s, y_s = next(dl_source_iter)
#         y_s_domain = torch.zeros(batch_size, dtype=torch.long)  # generate source domain labels
#
#         class_pred, domain_pred = model(X_s.to(device), grl_lambda)
#         loss_s_label = loss_fn_class(class_pred, y_s.to(device))
#         # a = 1
#         loss_s_domain = loss_fn_domain(domain_pred, y_s_domain.to(device))
#
#         # Train on target domain
#         X_t, _ = next(dl_target_iter)  # ignore target domain class labels!
#         y_t_domain = torch.ones(batch_size, dtype=torch.long)  # generate target domain labels
#
#         _, domain_pred = model(X_t.to(device), grl_lambda)
#         loss_t_domain = loss_fn_domain(domain_pred, y_t_domain.to(device))
#
#         loss = loss_t_domain + loss_s_domain + loss_s_label
#         loss.backward()
#         optimizer.step()
#         if batch_idx % 1000 == 0:
#             print(f'[{batch_idx + 1}/{max_batches}] '
#                   f'class_loss: {loss_s_label.item():.4f} ' f's_domain_loss: {loss_s_domain.item():.4f} '
#                   f't_domain_loss: {loss_t_domain.item():.4f} ' f'grl_lambda: {grl_lambda:.3f} '
#                   )
#
# ## 测试
#
# ds_test_source = tv.datasets.MNIST(root='./data', train=False, transform=tf_source, download=True)
# dl_test_source = torch.utils.data.DataLoader(ds_source, batch_size)
#
#
# ds_test_target = MNISTMDataset(os.path.join('./data', 'mnist_m', 'mnist_m_test'),
#                           os.path.join('./data', 'mnist_m', 'mnist_m_test_labels.txt'),
#                          transform=tf_target)
# # 使用dataloader加载器，边训练边加载图片，避免内存不够。较为灵活
# dl_test_target = torch.utils.data.DataLoader(ds_target, batch_size)
#
#
# def test(model,test_loader):
#     total_cnt = 0
#     length = 0.0
#     for i,(data,target) in enumerate(test_loader):
#         class_pred, domain_pred = model(data.to(device))
#         pred = class_pred.max(1)[1]
#         cnt = torch.sum(pred==target.to(device))
#         total_cnt = total_cnt + cnt
#         length = i
#         if i == 3000/batch_size:
#             break
#     print ('total correct is {} and total data is 3000'.format(total_cnt))
#     print ('corrent rate is {}'.format(total_cnt/(length*batch_size)))
# test(model,dl_test_source)
# test(model,dl_test_target)
#
#
#
